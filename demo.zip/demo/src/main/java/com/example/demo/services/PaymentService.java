package com.example.demo.services;

import com.example.demo.dto.PaymentResponse;
import com.example.demo.entitys.Payment;
import com.example.demo.entitys.Payment;
import com.example.demo.repositorly.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;

    // Injection de dépendance via le constructeur
    @Autowired
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    public PaymentResponse processPayment(String cardNumber) {
        long startTime = System.currentTimeMillis();

        // Simuler un temps de traitement
        try {
            Thread.sleep(500);  // Simuler un délai de 500ms pour le traitement
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String message;
        if (cardNumber.contains("1234")) {
            message = "Paiement réussi";
        } else {
            message = "Paiement échoué";
        }

        long processingTime = System.currentTimeMillis() - startTime;

        // Crée un objet Payment et enregistrez-le dans la base de données
        Payment payment = new Payment(cardNumber, message, processingTime);
        paymentRepository.save(payment);  // Appel correct de save

        return new PaymentResponse(message, processingTime);
    }
}
