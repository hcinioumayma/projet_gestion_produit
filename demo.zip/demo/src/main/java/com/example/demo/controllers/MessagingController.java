package com.example.demo.controllers;

import com.example.demo.entitys.Admin;
import com.example.demo.entitys.Customer;
import com.example.demo.entitys.Message;
import com.example.demo.services.MessagingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/messages")
public class MessagingController {

    private final MessagingService messagingService;

    @Autowired
    public MessagingController(MessagingService messagingService) {
        this.messagingService = messagingService;
    }

    // Endpoint pour envoyer un message
    @PostMapping("/send")
    public Message sendMessage(@RequestParam Long customerId, @RequestParam Long adminId, @RequestParam String content) {
        // Récupérer le customer et l'admin
        Customer customer = new Customer(); // Idéalement récupérez le customer depuis la base de données
        Admin admin = new Admin(); // Idem pour l'admin

        customer.setId(customerId);
        admin.setId(adminId);

        return messagingService.sendMessage(customer, admin, content);
    }

    // Endpoint pour récupérer les messages entre un customer et un admin
    @GetMapping("/chat")
    public List<Message> getMessages(@RequestParam Long customerId, @RequestParam Long adminId) {
        // Récupérer le customer et l'admin
        Customer customer = new Customer(); // Idem, récupérez depuis la DB
        Admin admin = new Admin(); // Récupérez depuis la DB

        customer.setId(customerId);
        admin.setId(adminId);

        return messagingService.getMessagesBetweenCustomerAndAdmin(customer, admin);
    }
}
