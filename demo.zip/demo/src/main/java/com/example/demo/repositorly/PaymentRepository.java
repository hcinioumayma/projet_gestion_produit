package com.example.demo.repositorly;

import com.example.demo.entitys.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    // Vous pouvez ajouter des méthodes personnalisées si nécessaire
}
