package com.example.demo.dto;

public class PaymentResponse {
    private String message;
    private long processingTimeMillis;

    // Constructeur
    public PaymentResponse(String message, long processingTimeMillis) {
        this.message = message;
        this.processingTimeMillis = processingTimeMillis;
    }

    // Getters et setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getProcessingTimeMillis() {
        return processingTimeMillis;
    }

    public void setProcessingTimeMillis(long processingTimeMillis) {
        this.processingTimeMillis = processingTimeMillis;
    }
}
