package com.example.demo.services;

import com.example.demo.entitys.Admin;
import com.example.demo.entitys.Customer;
import com.example.demo.entitys.Message;
import com.example.demo.repositorly.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MessagingService {

    private final MessageRepository messageRepository;

    @Autowired
    public MessagingService(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    // Méthode pour envoyer un message
    public Message sendMessage(Customer customer, Admin admin, String content) {
        // Créer un nouveau message
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        Message message = new Message(customer, admin, content, timestamp);

        // Enregistrer le message dans la base de données
        return messageRepository.save(message);
    }

    // Méthode pour récupérer tous les messages entre un customer et un admin
    public List<Message> getMessagesBetweenCustomerAndAdmin(Customer customer, Admin admin) {
        return messageRepository.findAll() // Vous pouvez ajuster cette méthode pour mieux filtrer les messages
                .stream()
                .filter(message -> message.getCustomer().equals(customer) && message.getAdmin().equals(admin))
                .collect(Collectors.toList());
    }
}
