package com.example.demo.repositorly;

import com.example.demo.entitys.Order;
import com.example.demo.entitys.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order,Long> {
}
