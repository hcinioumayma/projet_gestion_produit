package com.example.demo.services;

import com.example.demo.entitys.Admin;
import com.example.demo.repositorly.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    // Récupérer un administrateur par son ID
    public Optional<Admin> findById(Long id) {
        return adminRepository.findById(id);
    }

    // Sauvegarder un administrateur
    public Admin saveAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    // Supprimer un administrateur par son ID
    public void deleteAdmin(Long id) {
        adminRepository.deleteById(id);
    }

    // Trouver un administrateur par son nom d'utilisateur
    public Admin findByUsername(String username) {
        return adminRepository.findByUsername(username);
    }
}
