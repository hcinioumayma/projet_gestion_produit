package com.example.demo.controllers;

import com.example.demo.dto.PaymentResponse;
import com.example.demo.services.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@CrossOrigin(origins = "http://localhost:4200")

@RestController
@RequestMapping("/payment")
public class PaymentController {

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    // Endpoint pour traiter le paiement
    @PostMapping("/process")
    public PaymentResponse processPayment(@RequestParam String cardNumber) {
        // Appeler le service de paiement pour traiter la demande
        return paymentService.processPayment(cardNumber);
    }
}
